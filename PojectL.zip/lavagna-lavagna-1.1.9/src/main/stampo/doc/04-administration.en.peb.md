# Administration

To access the administration panel, click on the sidebar (the **<i class="fa fa-bars"></i>** icon in the top left position) and follow the **<i class="fa fa-cog"></i> Admin Panel** link in the side bar.

