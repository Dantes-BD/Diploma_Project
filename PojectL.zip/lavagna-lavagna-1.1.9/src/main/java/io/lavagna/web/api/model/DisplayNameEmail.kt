package io.lavagna.web.api.model

class DisplayNameEmail {
    var email: String? = null
    var displayName: String? = null
    var emailNotification: Boolean = false
    var skipOwnNotifications: Boolean = false
}

